// Slide navigation functions
function isDebug() {
  return (
    document.location.href.includes("127.0.0.1") ||
    document.location.href.includes("localhost")
  );
}

function goToSlideByName(slideName) {
  if (isDebug()) {
    window.location.href = "../" + slideName;
  } else {
    com.veeva.clm.gotoSlide(slideName + ".zip");
  }
}

function goToNextSlide() {
  com.veeva.clm.nextSlide();
}

function goToPreviousSlide() {
  com.veeva.clm.prevSlide();
}

// Calculate the design height from the body dataset.
function getDesignHeight() {
  return parseFloat(document.body.dataset.designHeight) || 768;
}

function pxValueToVh(value, designHeight) {
  var px = parseFloat(value);
  if (Number.isNaN(px)) return value + "px";
  var vh = (px / designHeight) * 100;
  return vh.toFixed(4).replace(/\.?0+$/, "") + "vh";
}

// Convert inline styles, style tags, and width/height attributes to vh.
function convertPxToVh(root, designHeight) {
  if (!designHeight || designHeight <= 0) {
    return;
  }
  var scope = root || document;

  // Inline style attributes.
  scope.querySelectorAll('[style*="px"]').forEach(function (el) {
    var style = el.getAttribute("style");
    if (!style) return;
    var converted = style.replace(/(-?\d*\.?\d+)px/g, function (_, value) {
      return pxValueToVh(value, designHeight);
    });
    if (converted !== style) {
      el.setAttribute("style", converted);
    }
  });

  // Style tags (supports header/footer fragments with embedded styles).
  scope.querySelectorAll("style").forEach(function (styleTag) {
    var css = styleTag.textContent;
    if (!css || css.indexOf("px") === -1) return;
    var converted = css.replace(/(-?\d*\.?\d+)px/g, function (_, value) {
      return pxValueToVh(value, designHeight);
    });
    if (converted !== css) {
      styleTag.textContent = converted;
    }
  });

  // Width/height attributes on elements (if defined in px).
  scope.querySelectorAll("[width],[height]").forEach(function (el) {
    ["width", "height"].forEach(function (attr) {
      var val = el.getAttribute(attr);
      if (!val || val.indexOf("px") === -1) return;
      var converted = val.replace(/(-?\d*\.?\d+)px/g, function (_, value) {
        return pxValueToVh(value, designHeight);
      });
      if (converted !== val) {
        el.setAttribute(attr, converted);
      }
    });
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function () {
    convertPxToVh(document, getDesignHeight());
  });
} else {
  convertPxToVh(document, getDesignHeight());
}
